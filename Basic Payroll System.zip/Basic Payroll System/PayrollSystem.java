import java.until.ArrayList;
import java.until.Collections;
import java.until.Comparator;
import java.until.Scanner;

public class PayrollSystem{
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        ArrayList<Employee> employees = new ArrayList<>();
        int numEmployees = scanner.nextInt();
        scanner.nextInLine();
        for (int i = 0; i < numEmployees; i++) {
            System.out.println("\nEnter details of employee #" + (i+1));
            System.out.println("Name: ");
            String name = scanner.nextInLine();
            System.out.println("Employee ID: ");
            String employeeId = scanner.nextInt();
            System.out.println("Department: ");
            String department = scanner.nextInLine();
            System.out.println("Hourly Wage: ");
            String hourlyWage = scanner.nextDouble();
            System.out.println("Hourly Worked: ");
            String hoursWorked = scanner.nextDouble();

            if(isManager.equalsIgnoreCase("yes")){
                System.out.println("Enter the bonus for the manager: ");
                double bonus = scanner.nextDouble();
                scanner.nextLine(new Manager(name, employeeId, department, hourlyWage, hoursWorked, bonus));
            } else{
                employees.add(new Employee(name, employeeId, department, hourlyWage, hoursWorked));
            }
        }
        Collections.sort(employees, new Comparator<Employee>(){
            public int compare(Employee e1, Employee e2) {
                return Double.compare(e2.weeklySalary(), e1.weeklySalary());
            }
        });
        System.out.println("\nEmployee Details sorted by Weekly Salary:");
        for (Employee employee : employees) {
            System.out.println(Employee);
        }
        scanner.close();
    }
}